# Code of Conduct

## 🌈 Our Pledge
We pledge to make participation in ClearTerms a harassment-free experience for everyone...