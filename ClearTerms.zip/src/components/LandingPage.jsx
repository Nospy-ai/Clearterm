import React from 'react';
import { Button } from "@/components/ui/button";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-white text-black flex flex-col items-center justify-center p-6">
      <h1 className="text-5xl font-bold mb-4 text-center">ClearTerms</h1>
      <p className="text-lg text-center max-w-2xl mb-8">
        Free, ad-free, and open-source. ClearTerms turns confusing Terms of Service into plain English.
      </p>
      <div className="flex gap-4">
        <Button onClick={() => window.location.href = '/app'}>Launch Web App</Button>
        <Button variant="outline" onClick={() => window.location.href = 'https://github.com/YOUR_USERNAME/clearterms'}>View on GitHub</Button>
      </div>
      <div className="mt-12 text-center text-sm max-w-lg">
        <p>📘 Built with ❤️ by a mission to make digital rights accessible to all.</p>
        <p className="mt-2">Want to support the mission? <a href="https://www.buymeacoffee.com/clearterms" className="text-blue-600 underline">Buy us a coffee</a>.</p>
      </div>
    </div>
  );
}