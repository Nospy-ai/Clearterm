---
name: Bug Report / Feature Request
about: Suggest a fix or new idea for ClearTerms
---

## 🐞 Bug Report OR 💡 Feature Request
...